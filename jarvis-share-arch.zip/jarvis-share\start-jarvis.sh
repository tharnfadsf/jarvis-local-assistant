#!/usr/bin/env bash
# J.A.R.V.I.S. share launcher for Arch Linux.
# Resolves its own folder, loads .env when present, then starts server.js.
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

OPEN_BROWSER=0
for arg in "$@"; do
  case "$arg" in
    --open) OPEN_BROWSER=1 ;;
    -h|--help)
      cat <<'EOF'
Usage: ./start-jarvis.sh [--open]

  --open   Open http://127.0.0.1:<port> in your default browser.
  -h       Show this help.

Environment:
  JARVIS_PORT   Port to use (default: 4199, or JARVIS_PORT from .env).
EOF
      exit 0
      ;;
    *)
      echo "Unknown option: $arg (try --help)" >&2
      exit 2
      ;;
  esac
done

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18+ is required." >&2
  echo "Install it on Arch Linux with: sudo pacman -S --needed nodejs npm" >&2
  exit 1
fi

if ! node -e 'const major = Number(process.versions.node.split(".")[0]); process.exit(major >= 18 ? 0 : 1)' >/dev/null 2>&1; then
  echo "Node.js $(node --version) is too old. Install Node.js 18 or newer." >&2
  exit 1
fi

if [ -f .env ]; then
  # Load .env without overriding variables already set in the environment.
  # Node emits shell-quoted exports so spaces and punctuation survive.
  eval "$(node - <<'NODE'
const fs = require('fs');
const source = fs.readFileSync('.env', 'utf8');
const quote = value => "'" + String(value).replace(/'/g, "'\\''") + "'";
for (const line of source.split(/\r?\n/)) {
  const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if (!match || process.env[match[1]] !== undefined) continue;
  let value = match[2];
  if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
  process.stdout.write(`export ${match[1]}=${quote(value)}\n`);
}
NODE
)"
else
  echo "No .env found; using built-in defaults."
  echo "Optional: cp .env.example .env && chmod 600 .env"
fi

PORT="${JARVIS_PORT:-4199}"
case "$PORT" in
  ''|*[!0-9]*)
    echo "JARVIS_PORT must be a number (got: $PORT)." >&2
    exit 1
    ;;
esac
export JARVIS_PORT="$PORT"
URL="http://127.0.0.1:$PORT"

if ! node -e '
const net = require("net");
const port = Number(process.argv[1]);
const server = net.createServer();
server.once("error", () => process.exit(1));
server.listen(port, "127.0.0.1", () => server.close(() => process.exit(0)));
' "$PORT" >/dev/null 2>&1; then
  echo "Port $PORT is already in use." >&2
  echo "Use another port, for example: JARVIS_PORT=4299 ./start-jarvis.sh --open" >&2
  exit 1
fi

echo "Starting J.A.R.V.I.S. ..."
echo "Open: $URL"
echo "Press Ctrl+C to stop."

if [ "$OPEN_BROWSER" = "1" ]; then
  if command -v xdg-open >/dev/null 2>&1; then
    ( sleep 2; xdg-open "$URL" >/dev/null 2>&1 || true ) &
  else
    echo "xdg-open is not installed; open the URL manually."
    echo "On Arch Linux: sudo pacman -S --needed xdg-utils"
  fi
fi

exec node server.js
