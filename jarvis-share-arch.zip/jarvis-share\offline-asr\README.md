# offline-asr — optional local speech bridge (not included)

This share package does **not** ship the Windows whisper.cpp binary or the
speech model. The current server enables local speech recognition only when
`process.platform === 'win32'` and these files exist:

    offline-asr/
      models/
        ggml-base.en-q8_0.bin
      runtime/
        Release/
          whisper-cli.exe
          whisper.dll
          ...

## On Arch Linux

Text chat, Ollama, the conversation library, memory, email, Discord, Fish
Audio TTS, and opening websites work without this folder. Microphone input
does **not** work on native Linux in this build, because the ASR bridge is a
Windows executable. You can still run JARVIS as a text-first assistant.

## On Windows

If you run this share on Windows, copy the real `models/` and `runtime/`
folders from a working Windows JARVIS install into this directory, keeping
the layout above. Then restart JARVIS.

Do **not** commit `.bin`, `.dll`, or `.exe` files to GitHub. The share
`.gitignore` already excludes them.
