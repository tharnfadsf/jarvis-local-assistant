'use strict';
/* JARVIS background low-power gate.
 *
 * The desktop host launches Edge with --disable-background-timer-throttling,
 * --disable-renderer-backgrounding and --disable-backgrounding-occluded-windows
 * so microphone capture, wake-word detection and the global push-to-talk
 * channel keep working while JARVIS is minimized. That also means the normal
 * browser throttling cannot be relied on, so the page opts itself into a
 * cosmetic low-power mode when it is hidden or merely unfocused.
 *
 * This module ONLY decides whether cosmetic work should run. Audio capture,
 * speech processing, wake routing, PTT events and answer delivery never consult
 * it; they must stay at full speed in the background.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.JarvisBackgroundPower = api;
})(typeof window !== 'undefined' ? window : null, function () {
  const LOW_POWER_CLASS = 'jarvis-low-power';

  // Hidden (minimized/occluded tab) and visible-but-unfocused (another app is
  // active, JARVIS may sit on a second monitor) are both background states.
  function isBackgroundState(visibilityState, hasFocus) {
    return visibilityState === 'hidden' || hasFocus === false;
  }

  function createBackgroundPower(options) {
    const settings = options || {};
    const doc = settings.document || (typeof document !== 'undefined' ? document : null);
    const win = settings.window || (typeof window !== 'undefined' ? window : null);
    const listeners = new Set();
    let background = null;
    let lastReason = 'init';
    let destroyed = false;

    function read() {
      if (!doc) return false;
      const hasFocus = typeof doc.hasFocus === 'function' ? doc.hasFocus() : true;
      return isBackgroundState(doc.visibilityState, hasFocus);
    }

    function applyClass(on) {
      if (!doc) return;
      try { if (doc.documentElement) doc.documentElement.classList.toggle(LOW_POWER_CLASS, on); } catch {}
      try { if (doc.body) doc.body.classList.toggle(LOW_POWER_CLASS, on); } catch {}
    }

    function sync(reason) {
      if (destroyed) return background;
      const next = read();
      lastReason = reason || lastReason;
      if (next === background) {
        // The first sync may already be at the correct value; still make sure
        // the class reflects it (for example after a hot reload).
        if (background === null) applyClass(next);
        return background;
      }
      background = next;
      applyClass(next);
      for (const listener of Array.from(listeners)) {
        try { listener(next, lastReason); }
        catch (error) {
          try { win && win.console && win.console.warn('[JARVIS low power] listener failed:', (error && error.message) || error); } catch {}
        }
      }
      return background;
    }

    function isBackground() {
      return background === null ? read() : background;
    }

    function onChange(listener, opts) {
      if (typeof listener !== 'function') return function () {};
      listeners.add(listener);
      if (!opts || opts.immediate !== false) {
        try { listener(isBackground(), 'subscribe'); } catch {}
      }
      return function () { listeners.delete(listener); };
    }

    function destroy() {
      if (destroyed) return;
      destroyed = true;
      if (doc && doc.removeEventListener) doc.removeEventListener('visibilitychange', onVisibility);
      if (win && win.removeEventListener) {
        win.removeEventListener('focus', onFocus);
        win.removeEventListener('blur', onBlur);
      }
      listeners.clear();
    }

    function onVisibility() { sync('visibility'); }
    function onFocus() { sync('focus'); }
    function onBlur() { sync('blur'); }

    if (doc && doc.addEventListener) doc.addEventListener('visibilitychange', onVisibility);
    if (win && win.addEventListener) {
      win.addEventListener('focus', onFocus);
      win.addEventListener('blur', onBlur);
    }
    sync('init');

    return {
      get background() { return isBackground(); },
      get reason() { return lastReason; },
      isBackground,
      sync,
      onChange,
      destroy
    };
  }

  return { LOW_POWER_CLASS, isBackgroundState, createBackgroundPower };
});
