# J.A.R.V.I.S. — Arch Linux Share Package

A clean, runnable copy of the current J.A.R.V.I.S. assistant build, packaged
for Arch Linux. The UI, server, themes, and runtime code are included. Personal
data, API keys, logs, local models, and Windows-only helper binaries are not.

The app has **no npm dependencies**. Node.js is the only requirement for the
web UI and server to start.

## Fastest install (downloaded archive)

Extract the archive so you have a `jarvis-share/` folder, then run:

```bash
cd jarvis-share
bash install-arch.sh --start
```

That installs Node.js if needed, creates `.env`, and launches JARVIS. Calling
the scripts with `bash` works even if your extractor did not keep the
executable bit. There is no `npm install` step.

## Quick start (Arch Linux)

```bash
# 1. Install Node.js (18 or newer)
sudo pacman -S --needed nodejs npm

# 2. Enter the share folder
cd jarvis-share

# 3. Optional: create your local config
cp .env.example .env
chmod 600 .env

# 4. Start
chmod +x start-jarvis.sh
./start-jarvis.sh --open
```

Open <http://127.0.0.1:4199> if the browser does not open automatically.

### One-step helper

```bash
chmod +x install-arch.sh
./install-arch.sh --start
```

`install-arch.sh` installs Node.js if it is missing, creates `.env` with mode
`600`, and makes the launcher executable. With `--start` it launches JARVIS
immediately. It does not install AI models.

### Start without the launcher

```bash
node server.js
```

The server binds to `127.0.0.1` only. It is not exposed to your LAN.

## Local AI (recommended)

JARVIS uses Ollama for local conversation. Install it once:

```bash
sudo pacman -S --needed ollama
sudo systemctl enable --now ollama
ollama pull qwen3:1.7b
```

The UI defaults to `qwen3:1.7b`; you can choose another installed model in the
AI panel. Check the service with:

```bash
curl http://127.0.0.1:11434/api/tags
```

If you do not want a local model, you can configure a remote provider in
`.env` (OpenCode, OpenRouter, or a self-hosted Freebuff-compatible endpoint).
With no keys configured, JARVIS falls back to local Ollama.

> `ai-config.json` controls routing. Set `"mode": "local"` to guarantee that
> conversation content never leaves the machine, even if a key exists.

## What works on Arch Linux

| Feature | Status on native Arch Linux |
|---|---|
| Web UI, HUD, themes, chat window | **Yes** |
| Local AI through Ollama | **Yes** (install a model) |
| Remote AI providers | **Yes**, when configured |
| Conversation library / emotional replies | **Yes** |
| Memory vault (Markdown) | **Yes** |
| Calendar and reminder records | **Yes** (core logic) |
| Persistent OS alarms | Windows-only (Task Scheduler) |
| Email drafting, SMTP, IMAP | **Yes**, with credentials |
| Discord webhook and notifications | **Yes**, with credentials |
| Fish Audio cloud voice (TTS) | **Yes**, with an API key |
| Open websites in your default browser | **Yes** (uses `xdg-open`) |
| App launch/close, window control, typing/clicking | Windows-only |
| Browser tab control, YouTube tab actions, restore tabs | Windows-only |
| Screen vision, screen help, computer tools | Windows-only |
| Microphone input / offline Whisper ASR | Windows-only in this build |
| Local system voice fallback | Windows-only |
| Media-session playback control | Windows-only |
| System monitor | Basic CPU/RAM on Linux; Windows-only details |

Voice input is the main limitation: the current ASR bridge is a Windows
`whisper-cli.exe`. On Arch Linux the share is text-first. See
`offline-asr/README.md` for details.

## Configuration

Copy `.env.example` to `.env` and edit only what you need. The launcher loads
`.env` automatically. Never commit it.

Common settings:

| Variable | Purpose |
|---|---|
| `JARVIS_PORT` | Local port (default `4199`) |
| `JARVIS_OLLAMA_URL` | Ollama address (default `http://127.0.0.1:11434`) |
| `JARVIS_VAULT_PATH` | Memory vault folder (default `~/Documents/JARVIS`) |
| `JARVIS_PLANNER_FILE` | Calendar/reminder JSON (default `./planner-data.json`) |
| `JARVIS_TAB_CONTROL` | Keep `off` on Linux; Windows-only feature |
| `FISH_API_KEY` | Optional Fish Audio TTS key |
| `JARVIS_GOOGLE_ACCOUNT` | Optional Google account for Gmail/Drive links |
| `OPENCODE_API_KEY` / `OPENROUTER_API_KEY` | Optional remote AI keys |

For Gmail, use an App Password, not your normal account password. Email and
Discord are completely optional; leave the variables commented out if you do
not use them.

### Data written at runtime

The share is safe to commit because runtime data is ignored:

- `planner-data.json` — calendar, reminders, alarms (in the app folder by
  default; move it with `JARVIS_PLANNER_FILE`).
- `~/Documents/JARVIS/` — Markdown memory notes and conversation logs.
- `~/JARVIS/` — mail drafts and local settings on Linux (the code falls back
  to the home directory when `LOCALAPPDATA` is not set).
- `JARVIS/logs/asr-failures/` — only if Windows ASR is used and fails.

## Verify the package

```bash
node verify-share.js
# or: npm run verify
```

This starts a temporary server on a free local port with temporary data paths,
checks `/api/health`, the UI, every script the page loads, the conversation
library, and the config files, then shuts it down. It does not touch your real
`.env`, planner, or memory vault.

## Push to GitHub

All files are well under GitHub's 25 MB web-upload limit; the largest file is
`app.js` at about 650 KB. From this folder:

```bash
git init -b main
git add .
git status --short          # confirm only the share files are staged
git commit -m "JARVIS share build"
gh repo create <your-name>/jarvis --private --source=. --push
```

Without the GitHub CLI:

```bash
git remote add origin https://github.com/<your-name>/jarvis.git
git push -u origin main
```

Useful checks before uploading:

```bash
du -sh .
find . -type f -size +25M
```

`.gitignore` already excludes `.env`, planner data, mail drafts, memory,
local models, logs, and backups. `.gitattributes` keeps shell scripts on LF
line endings so `start-jarvis.sh` works after a clone.

## Troubleshooting

**Port already in use**

```bash
JARVIS_PORT=4299 ./start-jarvis.sh --open
```

**`node: command not found` or Node is too old**

```bash
sudo pacman -S --needed nodejs npm
node --version
```

**Blank page**

Open the exact URL printed by the launcher (usually
`http://127.0.0.1:4199`) and hard-refresh with `Ctrl+F5`. Check the terminal
for a startup error.

**No AI replies**

```bash
systemctl status ollama
curl http://127.0.0.1:11434/api/tags
ollama pull qwen3:1.7b
```

Or add a remote provider key in `.env` and restart.

**`xdg-open` is missing**

```bash
sudo pacman -S --needed xdg-utils
```

**Permission denied running the scripts**

```bash
chmod +x start-jarvis.sh install-arch.sh
```

**`start-jarvis.sh` reports `$'\r'`**

The file was saved with Windows line endings. Fix it with:

```bash
sed -i 's/\r$//' start-jarvis.sh install-arch.sh
```

**Browser control or screen help says Windows-only**

That is expected in this build. Those features depend on Windows PowerShell,
UI Automation, or Edge/Chrome remote debugging. Website opening still works
through `xdg-open`.

**Voice/TTS fails**

Fish Audio TTS needs `FISH_API_KEY` and `FISH_REFERENCE_ID`. Local system voice
is Windows-only. Without either, JARVIS stays text-only and still works.

## Privacy and cleanup

- No `.env`, planner data, conversation logs, memory notes, mail drafts,
  training corpus, API keys, or personal paths are included.
- No Windows binaries, ASR models, or wake-word models are included.
- Runtime data stays on your machine. The server listens on loopback only.
- Remote AI and Fish Audio are contacted only after you configure their keys.
- To remove all local JARVIS data later, delete `planner-data.json`, the
  memory vault folder, and `~/JARVIS/` (after backing up anything you want).

## License

MIT, as declared in `package.json`.
