'use strict';
// Cross-platform smoke test for the share package.
// Starts server.js on a free local port with temporary data paths, checks the
// UI and every runtime asset it loads, then shuts the server down cleanly.
const fs = require('fs');
const os = require('os');
const path = require('path');
const net = require('net');
const { spawn } = require('child_process');
const { once } = require('events');

const ROOT = __dirname;
const REQUIRED = [
  'index.html',
  'app.js',
  'jarvis-core.js',
  'hud-theme.js',
  'music-orb.js',
  'hud-environment.js',
  'theme-scene.js',
  'server.js',
  'browser-tabs.js',
  'media-monitor.js',
  'system-monitor.js',
  'situation.js',
  'memory-vault.js',
  'ai-router.js',
  'discord.js',
  'mail.js',
  'screen-vision.js',
  'screen-assist.js',
  'screen-help-phrases.js',
  'computer-tools.js',
  'youtube-discovery.js',
  'wakeword-oww.js',
  'manifest.json',
  'jarvis-icon.png',
  'conversation-library.json',
  'creator-vocab.json',
  'ai-config.json',
  'voice-correction-config.json',
  'package.json',
  '.env.example',
  'start-jarvis.sh',
  'offline-asr/README.md',
  'wakeword-models/README.md'
];

const ASSETS = [
  '/',
  '/app.js',
  '/jarvis-core.js',
  '/hud-theme.js',
  '/music-orb.js',
  '/hud-environment.js',
  '/theme-scene.js',
  '/situation.js',
  '/wakeword-oww.js',
  '/manifest.json',
  '/jarvis-icon.png',
  '/conversation-library.json',
  '/creator-vocab.json',
  '/ai-config.json',
  '/voice-correction-config.json'
];

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

async function fetchReady(url, child, logs, timeoutMs = 20000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    if (child.exitCode !== null) {
      throw new Error(`server exited early with code ${child.exitCode}\n${logs.join('')}`);
    }
    try {
      const response = await fetch(url);
      if (response.ok) return response;
    } catch {
      // Connection refused while the server is still starting.
    }
    await delay(250);
  }
  throw new Error(`server did not become ready at ${url} within ${timeoutMs} ms\n${logs.join('')}`);
}

async function main() {
  console.log('J.A.R.V.I.S. share verification');
  console.log(`  node ${process.version} on ${process.platform}`);

  const missing = REQUIRED.filter(file => !fs.existsSync(path.join(ROOT, file)));
  if (missing.length) throw new Error(`missing required file(s): ${missing.join(', ')}`);

  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'jarvis-share-verify-'));
  const port = await freePort();
  const base = `http://127.0.0.1:${port}`;
  const env = {
    ...process.env,
    JARVIS_INSTANCE: 'verify',
    JARVIS_PORT: String(port),
    JARVIS_ENV_FILE: path.join(temp, 'empty.env'),
    JARVIS_PLANNER_FILE: path.join(temp, 'planner-data.json'),
    JARVIS_VAULT_PATH: path.join(temp, 'vault'),
    JARVIS_ASR_FAILURE_DIR: path.join(temp, 'asr'),
    JARVIS_TAB_CONTROL: 'off',
    JARVIS_NOTIFY_POLL_MS: '600000',
    JARVIS_HEARTBEAT_MS: '600000',
    JARVIS_SYSTEM_INTERVAL: '600000',
    JARVIS_TAB_MONITOR_MS: '600000',
    JARVIS_DISCOVERY_OLLAMA: 'off'
  };
  delete env.JARVIS_PARENT_PID;
  fs.writeFileSync(env.JARVIS_ENV_FILE, '', 'utf8');

  const logs = [];
  const child = spawn(process.execPath, ['server.js'], {
    cwd: ROOT,
    env,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe']
  });
  child.stdout.on('data', chunk => logs.push(String(chunk)));
  child.stderr.on('data', chunk => logs.push(String(chunk)));

  try {
    console.log(`  test port ${port}`);

    const healthResponse = await fetchReady(`${base}/api/health`, child, logs);
    const health = await healthResponse.json();
    if (!health || health.ok !== true) throw new Error('health endpoint did not report ok:true');
    if (health.platform !== process.platform) throw new Error(`health platform mismatch: ${health.platform}`);
    console.log(`  ok /api/health (platform ${health.platform})`);

    const bodies = new Map();
    for (const asset of ASSETS) {
      const response = await fetch(base + asset);
      if (!response.ok) throw new Error(`${asset} returned HTTP ${response.status}`);
      const buffer = Buffer.from(await response.arrayBuffer());
      if (!buffer.length) throw new Error(`${asset} is empty`);
      bodies.set(asset, buffer);
      console.log(`  ok ${asset} (${buffer.length} bytes)`);
    }

    const html = bodies.get('/').toString('utf8');
    if (!html.includes('J.A.R.V.I.S.')) throw new Error('index.html does not look like the JARVIS UI');
    for (const script of ['/jarvis-core.js', '/hud-theme.js', '/app.js', '/music-orb.js', '/hud-environment.js', '/theme-scene.js']) {
      if (!html.includes(script)) throw new Error(`index.html is missing ${script}`);
    }

    const library = JSON.parse(bodies.get('/conversation-library.json').toString('utf8'));
    if (!Array.isArray(library.categories)) throw new Error('conversation-library.json has no categories');
    const intents = library.categories.reduce((total, category) => total + (Array.isArray(category.intents) ? category.intents.length : 0), 0);
    if (!intents) throw new Error('conversation-library.json has no intents');
    console.log(`  ok conversation library (${intents} intents)`);

    const creators = JSON.parse(bodies.get('/creator-vocab.json').toString('utf8'));
    if (!Array.isArray(creators.creators)) throw new Error('creator-vocab.json has no creators array');

    const aiConfig = JSON.parse(bodies.get('/ai-config.json').toString('utf8'));
    if (!aiConfig.mode) throw new Error('ai-config.json has no mode');

    console.log('\nVerification passed. The share starts and serves the full UI.');
  } finally {
    if (child.exitCode === null) {
      try { child.kill(); } catch {}
      await Promise.race([once(child, 'exit'), delay(2000)]).catch(() => {});
    }
    if (child.exitCode === null) {
      try { child.kill('SIGKILL'); } catch {}
    }
    fs.rmSync(temp, { recursive: true, force: true });
  }
}

main().catch(error => {
  console.error('\nVerification failed:', error.message);
  process.exitCode = 1;
});
