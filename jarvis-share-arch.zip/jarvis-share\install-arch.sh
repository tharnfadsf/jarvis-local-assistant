#!/usr/bin/env bash
# Convenience setup for Arch Linux. Installs Node.js if needed, creates .env,
# and makes the launcher executable. It never installs optional AI models.
set -euo pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

START=0
for arg in "$@"; do
  case "$arg" in
    --start) START=1 ;;
    -h|--help)
      cat <<'EOF'
Usage: bash install-arch.sh [--start]

  --start   Install/setup, then launch JARVIS and open the browser.
  -h        Show this help.
EOF
      exit 0
      ;;
    *)
      echo "Unknown option: $arg (try --help)" >&2
      exit 2
      ;;
  esac
done

if ! command -v pacman >/dev/null 2>&1; then
  echo "This helper is for Arch Linux (pacman was not found)." >&2
  echo "Install Node.js 18+ manually, then run ./start-jarvis.sh" >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "Installing Node.js and npm..."
  sudo pacman -S --needed nodejs npm
else
  echo "Node.js is already installed: $(node --version)"
fi

if ! node -e 'const major = Number(process.versions.node.split(".")[0]); process.exit(major >= 18 ? 0 : 1)' >/dev/null 2>&1; then
  echo "Node.js is too old. Install Node.js 18 or newer." >&2
  exit 1
fi

if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env
  echo "Created .env from .env.example (mode 600)."
else
  chmod 600 .env 2>/dev/null || true
  echo "Keeping the existing .env."
fi

chmod +x start-jarvis.sh install-arch.sh 2>/dev/null || true

cat <<'EOF'

Setup complete.

Optional local AI:
  sudo pacman -S --needed ollama
  sudo systemctl enable --now ollama
  ollama pull qwen3:1.7b
EOF

if [ "$START" = "1" ]; then
  echo
  exec "$HERE/start-jarvis.sh" --open
fi

cat <<'EOF'

Start JARVIS:
  ./start-jarvis.sh --open

Then open http://127.0.0.1:4199 if the browser did not open.
EOF
