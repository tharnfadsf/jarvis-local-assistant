# wakeword-models — optional openWakeWord files (not included)

The UI can load an optional openWakeWord `hey_jarvis` early-hint sidecar if
these files are present:

    wakeword-models/
      melspectrogram.onnx
      embedding_model.onnx
      hey_jarvis_v0.1.onnx

They are **not** included. Download them from the official openWakeWord
releases (https://github.com/dscripka/openWakeWord/releases) if you want to
experiment with the sidecar.

The models are local-only. openWakeWord code is Apache-2.0; the pre-trained
models are CC BY-NC-SA 4.0 according to the upstream project, so verify the
license before commercial use.

Important: on native Arch Linux this share is text-first. The wake-word
sidecar is an early hint for the browser audio pipeline; it does not replace
the Windows-only speech-to-text bridge described in `offline-asr/README.md`.
Do not commit `.onnx` or `.tflite` files to Git.
